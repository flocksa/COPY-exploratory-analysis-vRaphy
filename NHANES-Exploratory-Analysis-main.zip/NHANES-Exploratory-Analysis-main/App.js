import React from 'react';
import NHANESUI from './NHANESUI';

function App() {
    return <NHANESUI />;
}

export default App;
